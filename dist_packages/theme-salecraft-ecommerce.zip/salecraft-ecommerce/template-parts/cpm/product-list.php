<?php
/**
 * Theme Template Part: Danh Sách Sản Phẩm (Product List Grid & Pagination)
 * Path: template-parts/cpm/product-list.php
 */

if (!defined('ABSPATH')) {
    exit;
}
// Passed variables: $query, $paged
?>
<div class="max-w-[1200px] mx-auto my-8 px-4 font-sans box-border">
    <?php if ($query->have_posts()) : ?>
        <div class="cpm-products-grid">
            <?php while ($query->have_posts()) : $query->the_post(); ?>
                <?php echo cpm_render_product_card(get_the_ID()); ?>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>

        <?php if ($query->max_num_pages > 1) : ?>
            <div class="cpm-pagination flex items-center justify-center gap-2 mt-10 mb-6 w-full flex-wrap">
                <?php
                $big = 999999999;
                $pagination_links = paginate_links(array(
                    'base'      => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                    'format'    => '?paged=%#%',
                    'current'   => max(1, $paged),
                    'total'     => $query->max_num_pages,
                    'prev_text' => '← Trang trước',
                    'next_text' => 'Trang sau →',
                    'type'      => 'array',
                    'mid_size'  => 2
                ));

                if (!empty($pagination_links)) {
                    foreach ($pagination_links as $link) {
                        if (strpos($link, 'current') !== false) {
                            echo str_replace(
                                'class="page-numbers current"',
                                'class="cpm-pagination-link active"',
                                $link
                            );
                        } else {
                            echo str_replace(
                                'class="page-numbers',
                                'class="cpm-pagination-link inactive',
                                $link
                            );
                        }
                    }
                }
                ?>
            </div>
        <?php endif; ?>

        <div id="cpm-toast" class="cpm-toast-notification fixed top-6 right-6 bg-slate-900 text-white py-3 px-4 rounded-xl shadow-2xl z-[99999] text-sm font-medium flex items-center gap-2.5 opacity-0 -translate-y-4 pointer-events-none transition-all duration-300">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            <span id="cpm-toast-msg">Đã thêm sản phẩm vào giỏ hàng!</span>
        </div>
    <?php else : ?>
        <div class="p-8 bg-slate-50 border border-dashed border-slate-300 rounded-xl text-center text-slate-500 font-medium w-full">
            Chưa có sản phẩm nào. Hãy truy cập Trang quản trị (Admin) -> menu <strong>Sản phẩm</strong> để thêm sản phẩm mới.
        </div>
    <?php endif; ?>
</div>

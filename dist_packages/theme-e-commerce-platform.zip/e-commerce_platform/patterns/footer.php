<?php
/**
 * Title: Footer
 * Slug: e-commerce_platform/footer
 * Categories: footer, e-commerce_platform
 * Block Types: core/template-part/footer
 *
 * @package E-Commerce Platform Theme
 * @since 1.0.0
 */
?>

<!-- wp:group {"className":"footer-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group footer-section">

    <!-- wp:columns {"className":"footer-boxes"} -->
    <div class="wp-block-columns footer-boxes">

        <!-- CỘT 1 -->
        <!-- wp:column {"className":"footer-column footer-brand"} -->
        <div class="wp-block-column footer-column footer-brand">

            <h3 class="footer-title">
                E-Commerce Platform
            </h3>

            <p class="footer-description">
                Nền tảng thương mại điện tử trực tuyến hiện đại,
                mang đến trải nghiệm mua sắm nhanh chóng,
                tiện lợi và an toàn.
            </p>

            <div class="footer-contact">
                <p>
                    <span>📍</span>
                    NEO - Coworking Space Tân Phú, TP. Hồ Chí Minh
                </p>

                <p>
                    <span>📞</span>
                    +84 393 465 113
                </p>

                <p>
                    <span>✉️</span>
                    contact@ecommerce-platform.com
                </p>
            </div>

        </div>

        <!-- CỘT 2 -->
        <!-- wp:column {"className":"footer-column"} -->
        <div class="wp-block-column footer-column">

            <h4 class="footer-heading">
                Liên kết nhanh
            </h4>

            <ul class="footer-links">
                <li>
                    <a href="<?php echo esc_url(home_url('/')); ?>">
                        <span>🏠</span> Trang chủ
                    </a>
                </li>

                <li>
                    <a href="<?php echo esc_url(home_url('/san-pham/')); ?>">
                        <span>🛍️</span> Danh sách sản phẩm
                    </a>
                </li>

                <li>
                    <a href="<?php echo esc_url(home_url('/gio-hang/')); ?>">
                        <span>🛒</span> Giỏ hàng của tôi
                    </a>
                </li>

                <li>
                    <a href="<?php echo esc_url(home_url('/lich-su-don-hang/')); ?>">
                        <span>📋</span> Lịch sử đơn hàng
                    </a>
                </li>
            </ul>

        </div>

        <!-- CỘT 3 -->
        <!-- wp:column {"className":"footer-column"} -->
        <div class="wp-block-column footer-column">

            <h4 class="footer-heading">
                Hỗ trợ khách hàng
            </h4>

            <ul class="footer-links">
                <li>
                    <a href="<?php echo esc_url(home_url('/lien-he/')); ?>">
                        <span>📞</span> Liên hệ & Bản đồ
                    </a>
                </li>

                <li>
                    <a href="<?php echo esc_url(home_url('/chinh-sach/')); ?>">
                        <span>🛡️</span> Chính sách & Bảo mật
                    </a>
                </li>

                <li>
                    <a href="<?php echo esc_url(home_url('/hoa-don/')); ?>">
                        <span>📄</span> Tra cứu hóa đơn
                    </a>
                </li>
            </ul>

        </div>

    </div>
    <!-- /wp:columns -->


    <!-- COPYRIGHT -->
    <div class="footer-bottom">

        <p>
            © <?php echo date('Y'); ?>
            <strong>E-Commerce Platform</strong>.
            All rights reserved.
        </p>

        <p class="footer-payment">
            🔒 Thanh toán an toàn · 🚚 Giao hàng nhanh
        </p>

    </div>

</div>
<!-- /wp:group -->


<style>

/* ================================
   FOOTER
================================ */

.footer-section {
    width: 100%;
    background: #111827;
    color: #ffffff;
    padding: 60px 0 25px;
    margin: 0 !important;
}

/* Container */
.footer-section > .wp-block-columns,
.footer-section > .footer-bottom {
    width: 85%;
    max-width: 1200px;
    margin-left: auto !important;
    margin-right: auto !important;
}

/* ================================
   COLUMNS
================================ */

.footer-boxes {
    display: grid !important;
    grid-template-columns: 1.7fr 1fr 1fr;
    gap: 70px;
    margin-bottom: 50px !important;
}

/* Bỏ margin mặc định WordPress */
.footer-boxes .wp-block-column {
    margin: 0 !important;
}

/* ================================
   BRAND
================================ */

.footer-title {
    margin: 0 0 18px;
    font-size: 25px;
    font-weight: 800;
    line-height: 1.3;
    color: #ffffff;
    letter-spacing: -0.3px;
}

.footer-description {
    max-width: 430px;
    margin: 0 0 25px;
    font-size: 14px;
    line-height: 1.8;
    color: #cbd5e1;
}

/* ================================
   CONTACT
================================ */

.footer-contact {
    display: flex;
    flex-direction: column;
    gap: 11px;
}

.footer-contact p {
    display: flex;
    align-items: flex-start;
    gap: 9px;
    margin: 0;
    font-size: 13px;
    line-height: 1.6;
    color: #cbd5e1;
}

.footer-contact p span {
    width: 22px;
    flex-shrink: 0;
}

/* ================================
   HEADINGS
================================ */

.footer-heading {
    position: relative;
    margin: 4px 0 25px;
    padding-bottom: 12px;
    font-size: 18px;
    font-weight: 700;
    color: #ffffff;
}

.footer-heading::after {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    width: 35px;
    height: 3px;
    border-radius: 10px;
    background: #f97316;
}

/* ================================
   LINKS
================================ */

.footer-links {
    display: flex;
    flex-direction: column;
    gap: 14px;
    list-style: none !important;
    margin: 0 !important;
    padding: 0 !important;
}

.footer-links li {
    margin: 0 !important;
    padding: 0 !important;
}

.footer-links a {
    display: flex;
    align-items: center;
    gap: 9px;
    width: fit-content;
    text-decoration: none !important;
    font-size: 14px;
    line-height: 1.5;
    color: #cbd5e1 !important;
    transition: all 0.25s ease;
}

.footer-links a span {
    font-size: 14px;
    transition: transform 0.25s ease;
}

.footer-links a:hover {
    color: #f97316 !important;
    transform: translateX(5px);
}

.footer-links a:hover span {
    transform: scale(1.1);
}

/* ================================
   BOTTOM
================================ */

.footer-bottom {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;

    padding-top: 22px;
    border-top: 1px solid rgba(255, 255, 255, 0.12);
}

.footer-bottom p {
    margin: 0;
    font-size: 12px;
    line-height: 1.6;
    color: #94a3b8;
}

.footer-bottom strong {
    color: #ffffff;
    font-weight: 600;
}

.footer-payment {
    text-align: right;
}

/* ================================
   TABLET
================================ */

@media (max-width: 900px) {

    .footer-boxes {
        grid-template-columns: 1fr 1fr;
        gap: 45px;
    }

    .footer-brand {
        grid-column: 1 / -1;
    }

    .footer-description {
        max-width: 650px;
    }
}

/* ================================
   MOBILE
================================ */

@media (max-width: 600px) {

    .footer-section {
        padding: 45px 0 20px;
    }

    .footer-section > .wp-block-columns,
    .footer-section > .footer-bottom {
        width: 90%;
    }

    .footer-boxes {
        display: flex !important;
        flex-direction: column;
        gap: 35px;
        margin-bottom: 35px !important;
    }

    .footer-title {
        font-size: 22px;
    }

    .footer-heading {
        margin-bottom: 18px;
    }

    .footer-description {
        font-size: 13px;
    }

    .footer-links {
        gap: 12px;
    }

    .footer-links a {
        font-size: 13px;
    }

    .footer-bottom {
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
    }

    .footer-payment {
        text-align: left;
    }
}

</style>

<?php
/**
 * E-Commerce Platform Theme Functions
 * Path: wp-content/themes/e-commerce_platform/functions.php
 */

if (!defined('ABSPATH')) {
    exit;
}

function e_commerce_platform_setup() {
    add_theme_support('wp-block-styles');
    add_theme_support('align-wide');
    add_theme_support('responsive-embeds');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
}
add_action('after_setup_theme', 'e_commerce_platform_setup');

function e_commerce_platform_scripts() {
    wp_enqueue_style('e-commerce-platform-style', get_stylesheet_uri(), array(), '1.0.0');
}
add_action('wp_enqueue_scripts', 'e_commerce_platform_scripts');
